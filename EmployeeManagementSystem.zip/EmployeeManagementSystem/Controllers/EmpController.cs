﻿using EmployeeManagementSystem.Models;
using EmployeeManagementSystem.repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class EmpController : ControllerBase
    {
        private readonly IEmpRepository _employeeRepository;

        public EmpController(IEmpRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        [Route("addEmployee")]  //ems/api/v1/addEmployee
        [HttpPost]
        [Authorize(Roles = "Admin")]
        //Adds a new employee into database, If already exists then returns a conflict.
        public async Task<ActionResult<Employee>> AddEmployee(Employee employee)
        {
            if (ModelState.IsValid)
            {

                try
                {
                    if (employee == null)
                        return BadRequest();

                    var newEmployee = await _employeeRepository.AddEmployee(employee);
                    if (newEmployee == null)
                    {
                        return StatusCode(StatusCodes.Status409Conflict, "Employee already exists.");
                    }
                    return StatusCode(StatusCodes.Status200OK, "Employee has been successfully added.");
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        "Error Encountered : Failed to add employee.");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [Route("getAllEmployees")] //ems/api/v1/getAllEmployees
        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        //Fetches all the employee details from database.
        public async Task<ActionResult> GetAllEmployees()
        {
            if (ModelState.IsValid)
            {
                try
                {
                    return Ok(await _employeeRepository.GetAllEmployees());
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        "Error Encountered : Failed to get details from database.");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [Route("modifyEmployee")] //ems/api/v1/modifyEmployee
        [HttpPut]
        [Authorize(Roles = "Admin")]
        //Modify a single employee detail using Employee ID.
        public async Task<ActionResult<Employee>> ModifyEmployee(Employee employee)
        {
            if (ModelState.IsValid)
            {

                try
                {
                    if (employee == null)
                        return BadRequest();

                    var newEmployee = await _employeeRepository.UpdateEmployee(employee);
                    if (newEmployee == null)
                    {
                        return StatusCode(StatusCodes.Status404NotFound, "Employee Not found.");
                    }
                    return Ok(newEmployee);
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        "Error Encountered : Failed to modify details.");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [Route("getEmployee")] //ems/api/v1/getEmployee/{id}
        [HttpGet()]
        [Authorize(Roles = "Admin,User")]
        //Fetch a single employee detail using Employee ID.
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Employee res = await _employeeRepository.GetEmployee(id);

                    if (res != null)
                    {
                        return Ok(res);
                    }
                    return NotFound("Employee not found.");
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        "Error Encountered : Failed to retrieve data from database.");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [Route("deleteEmployee")] //ems/api/v1/deleteEmployee/{id}
        [HttpDelete()]
        [Authorize(Roles = "Admin")]
        //Delete a single employee detail using Employee ID.
        public async Task<ActionResult<Employee>> DeleteEmployee(int id)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var employeeToBeDeleted = await _employeeRepository.GetEmployee(id);

                    if (employeeToBeDeleted == null)
                    {
                        return NotFound($"No Employee found with Id = {id} in database.");
                    }

                    object p = await _employeeRepository.DeleteEmployee(id);
                    return Ok($"Employee with Id = {id} has been successfully deleted.");
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        "Error Encountered : Failed to delete employee from database.");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }
    }
}
