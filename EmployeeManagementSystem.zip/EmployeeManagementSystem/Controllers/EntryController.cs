﻿using EmployeeManagementSystem.Models;
using EmployeeManagementSystem.repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntryController : ControllerBase
    {
        private readonly IEntryRepository _EntryRepository;
        private readonly ILogger<EntryController> _logger;

        public EntryController(IEntryRepository EntryRepository, ILogger<EntryController> logger)
        {
            _EntryRepository = EntryRepository;
            _logger = logger;
        }

        [AllowAnonymous]
        [Route("entry")]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] UserLogin userLogin)
        {
            if (ModelState.IsValid)
            {
                if (userLogin == null)
                    return BadRequest();

                var user = await _EntryRepository.Authenticate(userLogin);

                if (user != null)
                {
                    var token = _EntryRepository.Generate(user);
                    _logger.LogInformation("Employee logged in");
                    LoginDTO loginDTO = new LoginDTO()
                    {
                        Employee = user,
                        Token = token
                    };
                    return Ok(loginDTO);
                }
                _logger.LogWarning("Employee NOt found");
                return NotFound("User not found");
            }
            else
            {
                return BadRequest(ModelState);
            }
        }


        /// <summary>
        /// Password Change for Valid userlogin
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns>Employee</returns>
        [Route("PasswordChange")]
        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<ActionResult<Employee>> PasswordChange(UserLogin userLogin)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (userLogin == null)
                        return BadRequest();

                    var newEmployee = await _EntryRepository.UpdatePasswordAsync(userLogin);
                    _logger.LogWarning("Employee changed password");
                    return Ok(newEmployee);

                }
                catch (Exception)
                {
                    _logger.LogError("Employee Unable to change password");
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        "Error Updating password of employee record");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        private string EncryptPassword(string password)
        {
            string Message = string.Empty;
            byte[] Encode = new byte[password.Length];
            Encode = Encoding.UTF8.GetBytes(password);
            Message = Convert.ToBase64String(Encode);
            return Message;
        }

    }
}
