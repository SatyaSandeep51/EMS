﻿using EmployeeManagementSystem.Context;
using EmployeeManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.repositories
{
    public class EntryRepository : IEntryRepository
    {
        private readonly IConfiguration config;
        private readonly ApplicationDbContext appDbContext;

        public EntryRepository(ApplicationDbContext appDbContext, IConfiguration config)
        {
            this.appDbContext = appDbContext;
            this.config = config;
        }



        public async Task<Employee> Authenticate(UserLogin userLogin)
        {
            var currentEmployee = await appDbContext.Employees.FirstOrDefaultAsync(user => user.EmployeeId == userLogin.UserId && user.Password == userLogin.Password);

            if (currentEmployee != null)
            {
                return currentEmployee;
            }
            return null;
        }


        public string Generate(Employee user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {

                new Claim(ClaimTypes.Role, user.Role)
            };

            var token = new JwtSecurityToken(config["Jwt:Issuer"],
              config["Jwt:Audience"],
              claims,
              expires: DateTime.Now.AddMinutes(60),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


        public async Task<Employee> GetEmployeeById(int userId)
        {
            return await appDbContext.Employees
                .FirstOrDefaultAsync(e => e.EmployeeId == userId);
        }

        public async Task<Employee> UpdatePasswordAsync(UserLogin user)
        {
            var employee = await appDbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == user.UserId);
            if (employee != null && employee.FirstVisit == true)
            {
                employee.Password = user.Password;
                employee.FirstVisit = false;

                _ = await appDbContext.SaveChangesAsync();
                employee = await appDbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employee.EmployeeId);
            }
            return employee;

        }
    }
}
