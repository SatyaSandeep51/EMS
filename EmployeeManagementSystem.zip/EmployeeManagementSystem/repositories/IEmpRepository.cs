﻿using EmployeeManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.repositories
{
    public interface IEmpRepository
    {
        Task<IEnumerable<Employee>> GetAllEmployees(); //Fetches all the employee details.
        Task<Employee> GetEmployee(int employeeId); //Retrieves a single employee by id.
        Task<Employee> AddEmployee(Employee employee); //Registers a new employee into database.
        Task<Employee> UpdateEmployee(Employee employee); //Updates the existing employee details.
        Task<Employee> DeleteEmployee(int employeeId); //Deletes a single employee by id.
    }
}
