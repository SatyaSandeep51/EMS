﻿using EmployeeManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.repositories
{
    public interface IEntryRepository
    {
        Task<Employee> Authenticate(UserLogin userLogin);

        Task<Employee> GetEmployeeById(int userId);
        string Generate(Employee user);
        Task<Employee> UpdatePasswordAsync(UserLogin user);

    }
}
