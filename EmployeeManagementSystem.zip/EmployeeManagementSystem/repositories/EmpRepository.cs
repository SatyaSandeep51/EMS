﻿using EmployeeManagementSystem.Context;
using EmployeeManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.repositories
{
    public class EmpRepository : IEmpRepository
    {
        private readonly ApplicationDbContext empDbContext;
        public EmpRepository(ApplicationDbContext empDbContext)
        {
            this.empDbContext = empDbContext;
        }

        //Adds a new employee into database if same employee doesn't exist.
        public async Task<Employee> AddEmployee(Employee employee)
        {
            var checkEmployee = await empDbContext.Employees.FirstOrDefaultAsync(e => e.Phone == employee.Phone);
            if (checkEmployee != null)
            {
                return null;
            }
            var res = await empDbContext.Employees.AddAsync(employee);
            await empDbContext.SaveChangesAsync();
            return res.Entity;  
        }

        //Deletes a particular employee by taking id as a parameter if exists.
        public async Task<Employee> DeleteEmployee(int employeeId)
        {
            var res = await empDbContext.Employees
                .FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
            if (res != null)
            {
                empDbContext.Employees.Remove(res);
                await empDbContext.SaveChangesAsync();

            }
            return res;

        }

        //Retrieves a particular employee by taking id as a parameter if exists.
        public async Task<Employee> GetEmployee(int id)
        {
            return await empDbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == id);
        }

        //Retrieves all the employee details from the database.
        public async Task<IEnumerable<Employee>> GetAllEmployees()
        {
            return await empDbContext.Employees.ToListAsync();
        }

        //Updates a specific employee details as per the admin request.
        public async Task<Employee> UpdateEmployee(Employee employee)
        {
            var res = await empDbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employee.EmployeeId);

            if (res != null)
            {
                res.FirstName = employee.FirstName;
                res.LastName = employee.LastName;
                res.MiddleName = employee.MiddleName;
                res.Email = employee.Email;
                res.Salary = employee.Salary;
                res.Phone = employee.Phone;
                res.Location = employee.Location;
                res.Department = employee.Department;
                res.Password = employee.Password;
                res.Role = employee.Role;
                res.FirstVisit = employee.FirstVisit;
                await empDbContext.SaveChangesAsync();
                res = await empDbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employee.EmployeeId);
            }
            return res;
           
        }
    }
}
