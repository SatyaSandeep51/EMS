﻿using EmployeeAPI.Models;
using EmployeeAPI.repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.Controllers
{
    //    REST APIs:
    //Endpoint Exposed Purpose
    ///ems/api/v1/getAllEmployees Fetch all the employee details
    ///ems/api/v1/getEmployee/{id} Fetch a single employee detail using Employee ID
    ///ems/api/v1/addEmployee Adds a new employee
    ///ems/api/v1/deleteEmployee/{id} Delete a single employee detail using Employee ID
    ///ems/api/v1/modifyEmployee/{id} Modify a single employee detail using Employee ID
    ///ems/api/v1/entry Login to the system

    [ApiController]
    [ApiVersion("v1")]
    [Route("[controller]/api/{version:apiVersion}")]
    
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        [Route("addEmployee")]
        [HttpPost]
       
        public async Task<ActionResult<Employee>> CreateEmployee(Employee employee)
        {
            try
            {
                if (employee == null)
                    return BadRequest();

                var createdEmployee = await _employeeRepository.AddEmployee(employee);
                return new StatusCodeResult(200);
                //return CreatedAtActionResult(nameof(_employeeRepository.GetEmployee(employee.EmployeeId));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new employee record");
            }
        }
        [Route("getAllEmployees")]
        [HttpGet]
        
        public async Task<ActionResult> GetEmployees()
        {
            try
            {
                return Ok(await _employeeRepository.GetEmployees());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }
        [Route("modifyEmployee")]
        [HttpPut]
        
        public async Task<ActionResult<Employee>> ModifyEmployee(Employee employee)
        {
            try
            {
                if (employee == null)
                    return BadRequest();

                var createdEmployee = await _employeeRepository.UpdateEmployee(employee);
                return Ok(createdEmployee);
                //return new StatusCodeResult(200);
                //return CreatedAtActionResult(nameof(_employeeRepository.GetEmployee(employee.EmployeeId));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error Updating new employee record");
            }
        }
        [Route("getEmployee")]
        [HttpGet("{id:int}")]
        
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            try
            {
                var result = await _employeeRepository.GetEmployee(id);

                if (result == null)
                {
                    return NotFound();
                }

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }
        [Route("deleteEmployee")]
        [HttpDelete("{id}")]
       
        public async Task<ActionResult<Employee>> DeleteEmployee(int id)
        {
            try
            {
                var employeeToDelete = await _employeeRepository.GetEmployee(id);

                if (employeeToDelete == null)
                {
                    return NotFound($"Employee with Id = {id} not found");
                }

                object p = await _employeeRepository.DeleteEmployee(id);
                return Ok("Deleted");
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }

        
        //[HttpGet("{id:int}")]
        //[Route("entry")]
        //public IActionResult Index()
        //{
        //    return View();
        //}
    }
}
