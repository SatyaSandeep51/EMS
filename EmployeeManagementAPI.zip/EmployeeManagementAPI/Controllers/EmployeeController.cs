﻿using EmployeeManagementAPI.Models;
using EmployeeManagementAPI.repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementAPI.Controllers
{
   

    [ApiController]
    //[ApiVersion("v1")]
    [Route("api/[controller]")]

    public class EmployeeManagementController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeManagementController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        [Route("EmployeeAddition")]
        [HttpPost]

        public async Task<ActionResult<Employee>> Create_Employee(Employee employee)
        {
            try
            {
                if (employee == null)
                    return BadRequest();

                var createdEmployee = await _employeeRepository.Add_Employee_Details(employee);
                return StatusCode(StatusCodes.Status200OK, "The given employee details have been successfully added in the database");
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "An error occurred while an employee record is being created!");
            }
        }
        [Route("EmployeesRetrieval")]
        [HttpGet]
        
        public async Task<ActionResult> Get_Employees()
        {
            try
            {
                return Ok(await _employeeRepository.Get_Employees_Details());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "An error occured while retrieving all employees data from database");
            }
        }
        [Route("EmployeeModification")]
        [HttpPut]
        
        public async Task<ActionResult<Employee>> Modify_Employee(Employee employee)
        {
            try
            {
                if (employee == null)
                    return BadRequest();

                var createdEmployee = await _employeeRepository.Update_Employee_Details(employee);
                return Ok(createdEmployee);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "An error occured while modifying an employee record");
            }
        }
        [Route("RetrieveEmployee")]
        [HttpGet()]
        
        public async Task<ActionResult<Employee>> Get_Employee(int id)
        {
            try
            {
                var output = await _employeeRepository.Get_Employee_Details(id);

                if (output == null)
                {
                    return NotFound();
                }

                return output;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "An error occured while retrieving the employee data from database");
            }
        }
        [Route("EmployeeDeletion")]
        [HttpDelete()]
       
        public async Task<ActionResult<Employee>> Delete_Employee(int id)
        {
            try
            {
                var employeeToDelete = await _employeeRepository.Get_Employee_Details(id);

                if (employeeToDelete == null)
                {
                    return NotFound($"Employee with registered Id = {id} is not found in the database");
                }

                object p = await _employeeRepository.Delete_Employee_Details(id);
                return Ok("The requested employee details have been deleted");
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "An error occured while deleting the data of given employee");
            }
        }

        
        
    }
}
