﻿using EmployeeManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementAPI.repositories
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<Employee>> Get_Employees_Details();
        Task<Employee> Get_Employee_Details(int EmpID);
        Task<Employee> Add_Employee_Details(Employee employee);
        Task<Employee> Update_Employee_Details(Employee employee);
        Task<Employee> Delete_Employee_Details(int EmpID);
    }
}
