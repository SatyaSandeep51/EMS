﻿using EmployeeManagementAPI.Context;
using EmployeeManagementAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementAPI.repositories
{
    class EmployeeRepository : IEmployeeRepository
    {
        private readonly ApplicationDbContext EmployeeDbContext;

        public EmployeeRepository(ApplicationDbContext applicationDbContext)
        {
            this.EmployeeDbContext = applicationDbContext;
        }


        public async Task<Employee> Add_Employee_Details(Employee employee)
        {
            var output = await EmployeeDbContext.Employees.AddAsync(employee);
            await EmployeeDbContext.SaveChangesAsync();
            return output.Entity;
           
        }

        public async Task<Employee> Delete_Employee_Details(int EmpID)
        {
            var output = await EmployeeDbContext.Employees
                .FirstOrDefaultAsync(element => element.EmployeeId == EmpID);
            if (output != null)
            {
                EmployeeDbContext.Employees.Remove(output);
                await EmployeeDbContext.SaveChangesAsync();
                
            }
            return output;

        }

        public async Task<Employee> Get_Employee_Details(int EmpID)
        {
            return await EmployeeDbContext.Employees
                .FirstOrDefaultAsync(element => element.EmployeeId == EmpID);
        }

        public async Task<IEnumerable<Employee>> Get_Employees_Details()
        {
            return await EmployeeDbContext.Employees.ToListAsync();
        }

        public async Task<Employee> Update_Employee_Details(Employee employee)
        {
            var output = await EmployeeDbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employee.EmployeeId);

            if (output != null)
            {
                output.FirstName = employee.FirstName;
                output.LastName = employee.LastName;
                output.MiddleName = employee.MiddleName;
                output.Email = employee.Email;
                output.Salary = employee.Salary;
                output.Phone = employee.Phone;
                output.Location = employee.Location;
                output.Department = employee.Department;

                await EmployeeDbContext.SaveChangesAsync();
                output = await EmployeeDbContext.Employees.FirstOrDefaultAsync(element => element.EmployeeId == employee.EmployeeId);
            }
                
            return output;
                
        }
    }
}
