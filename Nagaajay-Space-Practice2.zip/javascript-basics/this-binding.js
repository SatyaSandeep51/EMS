//this keyword

//implicit binding
const person= {
    name: 'NagaAjay',
    sayMyName: function () {
        console.log(`my name is ${this.name}`)
    }
}

person.sayMyName();

// Explicit Binding

function sayMyName() {
    console.log(`My name is ${this.name}`)
}

sayMyName.call(person);

// New Binding

function Person(name) {
    this.name=name;
}

const p1=new Person('Naga');
const p2=new Person('Ajay');

console.log(p1.name,p2.name);

// Default binding

globalThis.name="Cognizant";
sayMyName()

// Order of precdence of binding
// New > Explicit > implicit > default
