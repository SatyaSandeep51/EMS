class Person  {
    constructor(fname, lname) {
        this.firstName=fname;
        this.lastName=lname;
    }

    sayMyName() {
        return this.firstName+' '+this.lastName
    }
}

const classP1= new Person('Naga','Ajay')
console.log(classP1.sayMyName())


class SuperHero extends Person {
    constructor(fname,lname) {
        super(fname,lname)
        this.isSuperHero=true
    }

    firstCrime() {
        console.log('Fighting crime')
    }
}

const batman=new SuperHero('Bruce','wayne')
console.log(batman.sayMyName())