// Demo of for loop - String
const str='Nagaajay';

for(let i=0;i<str.length;i++) {
    console.log(str.charAt(i))
}

//Demo of for loop - Array
const arr=['N','a','g','a','a','j','a','y']
for(let i=0;i<arr.length;i++) {
    console.log(arr[i])
}

//Iterables and iterators - protocols

//For of loop

for(const char of str) {
    console.log(char)
}