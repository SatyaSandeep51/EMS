//This is Javscript code

let wish="Hello Javascript"; //string
let age=30;
let isApproved = true;
let firstName=undefined;
let selectedColor= null;

const name="Naga Ajay K";
console.log(wish);

//Dynamic typing
console.log(typeof(age));

let person ={
    name:'Ajay',
    age:30
};
person.name="arun";
console.log(person)

let myArray=['red','blue']
console.log(myArray);


function greet(person) {
    console.log("Hello "+person.name);
}
greet(person);

