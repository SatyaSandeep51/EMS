//functions that can pause and continue execution

//Normal fucntion

function NormalFunction() {
    console.log("Hello");
    console.log("world");
}

NormalFunction()
NormalFunction()

//Generator Function
function* generatorFunction() {
    yield 'Hello'
    yield 'World'
}

const generatorObject = generatorFunction()
for(const word of generatorObject) {
    console.log(word)
}