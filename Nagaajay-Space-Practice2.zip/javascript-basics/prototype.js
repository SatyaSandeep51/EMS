//Protype

function PersonName(fname,lname) {
    this.firstName=fname;
    this.lastName=lname;
 }
 
 const person1=new PersonName('Bruce', 'Wayne')
 const person2=new PersonName('Clark','Kent')
 
 PersonName.prototype.getFullName=function () {
     return this.firstName+' '+this.lastName
 }
 
 console.log(person1.getFullName())
 console.log(person2.getFullName())
 
 //Protypal Inheritance
 