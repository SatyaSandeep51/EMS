import React from 'react'

export default function Home() {
  return (
    <div><p>Hello </p>Home</div>
  )
}
