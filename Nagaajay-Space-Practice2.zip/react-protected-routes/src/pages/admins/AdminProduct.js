import React from 'react'

export default function AdminProduct() {
  return (
    <div><p>Hello</p>AdminProduct</div>
  )
}
