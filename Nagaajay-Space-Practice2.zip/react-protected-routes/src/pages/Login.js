import React from 'react'

export default function Login() {
  return (
    <div><p>Hello</p>Login</div>
  )
}
