import { Outlet, Navigate } from 'react-router-dom'

const UserRoutes = (props) => {
    let auth = {'token':true}
    
    return(
        auth.token && props.role==='USER' ? <Outlet/> : <Navigate to="/login"/>
    )
}

export default UserRoutes