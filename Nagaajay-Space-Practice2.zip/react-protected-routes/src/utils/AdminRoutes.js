import { Outlet, Navigate } from 'react-router-dom'

const AdminRoutes = (props) => {
    let auth = {'token':true}
    return(
        auth.token && props.role==='ADMIN' ? <Outlet/> : <Navigate to="/login"/>
    )
}

export default AdminRoutes