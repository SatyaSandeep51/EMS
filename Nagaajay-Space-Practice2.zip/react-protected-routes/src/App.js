import Login from './pages/Login'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css';
import PrivateRoutes from './utils/PrivateRoutes';
import Home from './pages/Home';
import Products from './pages/Products';
import AdminRoutes from './utils/AdminRoutes';
import AdminHome from './pages/admins/AdminHome';
import AdminProduct from './pages/admins/AdminProduct';
import UserRoutes from './utils/UserRoutes';
import UserHome from './pages/users/UserHome';
import UserProduct from './pages/users/UserProduct';

//https://github.com/divanov11/React-router-v6-protected-routes


function App() {
  const role='USER';
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route element={<PrivateRoutes />} >
            <Route element={<Home />} path="/Home" />
            <Route element={<Products />} path="/products" />
          </Route>
          <Route element={<AdminRoutes role={role} />}>
            <Route element={<AdminHome />} path="/admin-home" />
            <Route element={<AdminProduct />} path="/admin-product" />
          </Route>
          <Route element={<UserRoutes  role={role} />}>
            <Route element={<UserHome />} path="/user-home" />
            <Route element={<UserProduct />} path="/user-product" />
          </Route>
          <Route element={<Login />} path="/login" />
        </Routes>
      </Router>

    </div>
  );
}

export default App;
