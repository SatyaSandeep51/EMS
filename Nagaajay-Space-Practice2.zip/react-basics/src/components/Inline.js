
export const Inline=()=> {
    const heading = {
        fontSize:'72px',
        color:'blue'
    }
    return <h1 style={heading}>Inline Styling</h1>
}