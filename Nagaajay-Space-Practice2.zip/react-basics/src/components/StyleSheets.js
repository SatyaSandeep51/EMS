import './myStyle.css'

export const StyleSheets=()=> {
    return <h1 className='primary'>Welcome Ajay</h1>
}