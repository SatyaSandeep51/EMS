export const ChildComponent=(props)=> {
    return (
        <div>
            <button onClick={()=>props.greetHandler('child')}>greet Parent</button>
        </div>
    )
}