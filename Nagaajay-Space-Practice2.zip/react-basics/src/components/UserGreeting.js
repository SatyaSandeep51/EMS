export const UserGreeting=()=> {
    const isLoggedIn=true
    return <div>
        <h1>Welcome {isLoggedIn? 'Nagaajay':'Guest' }</h1>
        <p>Welcome { isLoggedIn && 'Nagaajay' }</p>
        </div>
}

