export const NameList=()=> {
    const names=['Naga','Ajay','Daina']
    return <div>
        {
            names.map((name)=> {
                return <h2 key={name}>{name}</h2>
            })
        }
    </div>
}