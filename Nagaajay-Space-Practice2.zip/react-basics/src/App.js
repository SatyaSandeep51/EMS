import './App.css';
import NAMES from './components/data.json'
import {useState, useTransition} from 'react'
import RadioButton from './components/RadioButton';

function App() {
  const [query, setQuery]=useState('')
  const [inputValue,SetInputValue]=useState('')
  const [isPending, startTransition]=useTransition()
  
  const changeHandler=(event)=> {
    SetInputValue(event.target.value)
    startTransition(()=> setQuery(event.target.value))
  }
  
  
  const filteredNames= NAMES.filter((item)=>{
    return item.first_name.includes(query) || item.last_name.includes(query)
  })
  
  
  
  return (
    <div className="App">
      <input type='text' value={inputValue} onChange={changeHandler} />
      {isPending && <p>Updating List.. Please Wait..</p>}
      {
        filteredNames.map((item)=> (
          <p key={item.id}>
            {item.first_name} {item.last_name}
          </p>
        ))
      }


    {/* <Greet name='prashanth' heroName='spiderman' >
      <p>This is a child tag</p>
    </Greet>

    <Message />
    <ClickHandler />

    <ParentComponent /> 
    <UserGreeting /> 
     <NameList /> 

    <StyleSheets />
    <Inline />
    <h1 className='error'>Error</h1>
    <h1 className={styles.success}>success</h1>
    <Form />
    <PostForm />
    <PostList /> */}
    {/* <RadioButton /> */}
    </div>
  );
}

export default App;
