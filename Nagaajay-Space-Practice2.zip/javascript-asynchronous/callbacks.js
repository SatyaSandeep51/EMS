// send a function as a parameter
function greet(name) {
    console.log(`Hello ${name}`)
}

function greetName(greetFn) {
    const name='Nagaajay'
    greetFn(name)
}

//greet is a callback function (synchronously)
greetName(greet)

//Asynchronous
//Problems with callback pattern
//Callback hell
//if you have multiple callback functions where each level depends on the result obatined from the previous level, the nesting of functions becomes so deep the code becomes difficult to read and maintain
//Solution: Promises