// Promise - like an object
// Promise Value
// Fullfull Promise
// reject promise
// success callback
// Failure callback


function resloveHello() {
    return new Promise(reslove=> {
        setTimeout(function () {
            reslove('Hello')
        },2000)
    })
}

function resloveWorld() {
    return new Promise(reslove => {
        setTimeout(function () {
            reslove('World')
        },1000)
    })
}



//run concurrently
async function concurrentStart() {
    const hello = resloveHello()
    const world = resloveWorld()

    console.log(await hello)
    console.log(await world)
}

concurrentStart()

//run parallely
function parallel() {
    Promise.all([
        (async () => console.log(await resloveHello()))(),
        (async ()=> console.log(await resloveWorld()))(),
    ])
}

parallel()
