//TimeOuts and Intervals

function greet() {
    console.log('Hello World');
}
setTimeout(greet,2000);

//with aruguments
function greetName(name) {
    console.log(`Hello ${name}`);
}
setTimeout(greetName,2000,'Nagaajay')

const intervalId=setInterval(greet,2000)
clearInterval(intervalId)