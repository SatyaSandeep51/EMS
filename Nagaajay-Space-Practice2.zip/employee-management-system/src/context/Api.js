import axios from 'axios';
export default function Api() {
    const http = axios.create({
        baseURL: "https://localhost:44305/api",
        headers: {
            headers: {'X-Requested-With': 'XMLHttpRequest'},

        }
        
    });
    return http;
}
