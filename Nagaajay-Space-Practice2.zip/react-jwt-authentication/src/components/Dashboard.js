import AuthUser from "./AuthUser"

export default function Dashboard() {
    const {user}=AuthUser()
    return (
        <div>
            <table class="table mt-3 table-sm">
                <thead class="table-dark">
                    <tr>
                        <th>Employee Id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{user.employeeId}</td>
                        <td>{user.firstName}</td>
                        <td>{user.lastName}</td>
                        <td>{user.email}</td>
                        <td>{user.role}</td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
    )
}