import React from 'react'
import AuthUser from './AuthUser'

export default function Details() {
    const {user}=AuthUser()
    return (
        <div class="container">
            <h2>Employee Details</h2>
            <p>Please check the your Details</p>
            <table class="table table-bordered">
                <tr>
                    <th>Employee ID</th>
                    <td>{user.employeeId}</td>
                </tr>
                <tr>
                    <th>Firstname</th>
                    <td>{user.firstName}</td>
                </tr>
                <tr>
                    <th>MiddleName</th>
                    <td>{user.middleName}</td>
                </tr>
                <tr>
                    <th>LastName</th>
                    <td>{user.lastName}</td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td>{user.phone}</td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>{user.email}</td>
                </tr>
                <tr>
                    <th>Salary</th>
                    <td>{user.salary}</td>
                </tr>
                <tr>
                    <th>Location</th>
                    <td>{user.location}</td>
                </tr>
                <tr>
                    <th>Department</th>
                    <td>{user.department}</td>
                </tr>
                <tr>
                    <th>Role</th>
                    <td>{user.role}</td>
                </tr>
            </table>
        </div>
    )
}
