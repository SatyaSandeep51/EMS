import React from 'react'

export default function Register() {



    return (
        <div class="container align-center">
            <h2>Register Employee</h2>

            <form class="needs-validation" novalidate>
                <div class="form-group col-md-4">
                    <label>First Name:</label>
                    <input type="text" class="form-control" id="fname" placeholder="Enter First name" name="fname" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <div class="form-group col-md-4">
                    <label>Middle Name:</label>
                    <input type="text" class="form-control" id="mname" placeholder="Enter Middle name" name="mname" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <div class="form-group col-md-4">
                    <label>Last Name:</label>
                    <input type="text" class="form-control" id="lname" placeholder="Enter Middle name" name="lname" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <div class="form-group col-md-4">
                    <label>Phone:</label>
                    <input type="phone" class="form-control" id="phone" placeholder="Enter Phone Number" name="phone" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <div class="form-group col-md-4">
                    <label>Email Address:</label>
                    <input type="email" class="form-control" id="email" placeholder="Enter Email address" name="email" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <div class="form-group col-md-4">
                    <label>Salary:</label>
                    <input type="number" class="form-control" id="salary" placeholder="Enter Salary Amount" name="salary" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>
                <div class="form-group col-md-4">
                    <label>Location:</label>
                    <input type="address" class="form-control" id="address" placeholder="Enter Address" name="address" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>

                <div class="form-group col-md-4">
                    <label>Department</label>
                    <select id="Department" class="form-control">
                        <option selected>Choose...</option>
                        <option>CDE</option>
                        <option>CDB</option>
                        <option>ADM</option>
                        <option>CDO</option>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label>Default Password:</label>
                    <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd" required />
                    <div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">Please fill out this field.</div>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>



    )
}
