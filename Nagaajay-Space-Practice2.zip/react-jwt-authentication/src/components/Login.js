import { useState } from "react"
import AuthUser from "./AuthUser";


export default function Login() {
    const {http,setToken} =AuthUser();
    const [employeeid, setEmployeeid] =useState();
    const [password, setPassword] =useState();

   const submitForm=()=> {
       console.log(employeeid+" "+password);
        const loginBody= {
            UserId: parseInt(employeeid),
            Password:password
        }
       //api call
       http.post("/Login/entry",loginBody)
       .then((res)=>{setToken(res.data.employee,res.data.token);
    }).catch(error=>console.log(error));
   } 

    return (
        <div className="row justify-content-center pt-5">
            <div className="col-sm-6" >
                <div className="card p-4">
                    <div className="form-group">
                        <label>Employee Id: </label>
                        <input type="number" className="form-control" placeholder="Enter employee ID"
                         onChange={e=>setEmployeeid(parseInt(e.target.value))}
                         id="employeeid" />
                    </div>
                    <div className="form-group mt-3">
                        <label>Password: </label>
                        <input type="password" className="form-control" placeholder="Enter password" 
                            onChange={e=>setPassword(e.target.value)}
                        id="pwd" />
                    </div>
                    <button type="button" onClick={submitForm}  className="btn btn-primary mt-4">Login</button>
                </div>

            </div>

        </div>
    )
}