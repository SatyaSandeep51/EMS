import React, { useMemo } from 'react'
import {useTable} from 'react-table'
import MOCK_DATA from './MOCK_DATA.json'
import {COLUMNS} from './columns'

import './table.css'

export default function RowSelection() {
  
    const columns = useMemo(()=>COLUMNS,[])
    const data = useMemo(()=>MOCK_DATA,[])
  
    const tableInstance = useTable({
        columns: columns,
        data: data
    })
    const {getTableProps,getTableBodyProps,headerGroups,rows,prepareRow}=tableInstance

   const firstPageRows= rows.slice(0,10)
    return (
    // https://stackoverflow.com/questions/58940952/why-use-usetable-over-reacttable-when-using-react-table
    <table {...getTableProps()}>
        <thead>
            {
                headerGroups.map((headerGroup)=>(
                    <tr {...headerGroup.getHeaderGroupProps()}>
                        {
                            headerGroup.headers.map((column)=> (
                                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                            ))
                        }
                    </tr>
                ))
            }
           
        </thead>
        <tbody {...getTableBodyProps()}>
            {
                firstPageRows.map((row,i)=> {
                    prepareRow(row);
                    return (
                        <tr {...row.getRowProps()}>
                            {
                                row.cells.map((cell)=> {
                                    return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                })
                            }
                           
                        </tr>
                    )
                })
            }
            
        </tbody>
    </table>
  )
}
